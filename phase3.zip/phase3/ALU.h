// drishti2511


// class and function definitions




#include <bits/stdc++.h>
using namespace std;
#define fio                         \
  ios_base::sync_with_stdio(false); \
  cin.tie(NULL)
typedef long long ll;
#define lop(i, a, b) for (i = a; i < b; i++)

#define max3(a, b, c) max(max((a), (b)), (c))
#define max4(a, b, c, d) max(max((a), (b)), max((c), (d)))
#define min3(a, b, c) min(min((a), (b)), (c))
#define min4(a, b, c, d) min(min((a), (b)), min((c), (d)))
#define all(v) (v).begin(), (v).end()
#define YES cout << "YES" << endl
#define NO cout << "NO" << endl
#define input(v, n) lop(i, 0, n) cin >> v[i]
#define take(x)     \
  for (auto &y : x) \
  cin >> y
#define show(x)       \
  for (auto y : x)    \
    cout << y << " "; \
  cout << endl
#define deb(x) cout << x << " "
// gcd func __gcd(m,n)
// g++ --std c++11 t4.cpp
// end of template

class ArithmeticLogicUnit
{

public:
  int output32 = 0;        // ALU result
  bool outputBool = false; // output32 Bool
  int input1 = 0;          // rs1
  int input2 = 0;          // rs2 or imm
  int MAX_SIGNED = 0x7fffffff;
  int MIN_SIGNED = -0x80000000;
  int MAX_UNSIGNED = 0xffffffff;
  int MIN_UNSIGNED = 0x00000000;
  int mask32 = 0x80000000;
  int bit_0_to_31_mask = 0x7fffffff;
  void ALUexecute(int ALUop, int ALUcontrol, int input_1, int input_2)
  {
    if (ALUop == 0)
    {
      output32 = 0; // ALU result
      outputBool = false;
      return;
    }
   
    input1 = input_1;
    input2 = input_2;
    if (ALUcontrol == 0)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = add(input_1, input_2);
    }
    else if (ALUcontrol == 1)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = bitwise_and(input_1, input_2);
    }
    else if (ALUcontrol == 2)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = bitwise_or(input_1, input_2);
    }
    else if (ALUcontrol == 3)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = shift_left(input_1, input_2);
    }
    else if (ALUcontrol == 4)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = shift_right_logical(input_1, input_2);
    }
    else if (ALUcontrol == 5)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = shift_right_arithmetic(input_1, input_2);
    }
    else if (ALUcontrol == 6)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = IfLessThan(input_1, input_2);
    }
    else if (ALUcontrol == 7)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = subtract(input_1, input_2);
    }
    else if (ALUcontrol == 8)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = bitwise_xor(input_1, input_2);
    }
    else if (ALUcontrol == 12)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = auipc_lui(input_1, input_2);
    }
    else if (ALUcontrol == 13)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = isEqual(input_1, input_2);
    }
    else if (ALUcontrol == 14)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = NotEqual(input_1, input_2);
    }
    else if (ALUcontrol == 15)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = Greater_than_equal(input_1, input_2);
    }
    else if (ALUcontrol == 16)
    {
       cout<<"Stage3: Execute"<<endl;
      int x = Less_Than(input_1, input_2);
    }
  }

  int IfLessThan(int input1, int input2)
  {
    if (input1 < input2)
    {
      outputBool = true;
    }
    else
      outputBool = false;
    output32 = int(outputBool);
    return output32;
  }
  int add(int input1, int input2) // ALU control=0 for add,addi,lb,lh,lw,sb,sh,sw
  {
    int temp = input1 + input2;
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "+"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }
  int bitwise_and(int input1, int input2) // ALU control=1 for and,andi
  {
    int temp = input1 & input2;
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "&"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }
  int bitwise_or(int input1, int input2) // ALU control=2 for or,ori
  {
    int temp = input1 | input2;
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "|"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }
  int shift_left(int input1, int input2) // ALU control=3 for sll
  {
    int temp = (input1 << input2) & MAX_UNSIGNED;          // for 32 bit
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask)); // for signed 32 bit
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "<<"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }
  int shift_right_logical(int input1, int input2) // ALU control=4 for srl
  {
    input1 = input1 & MAX_UNSIGNED;                        // we dont consider the sign bit in srl
    int temp = (input1 >> input2) & MAX_UNSIGNED;          // for 32 bit
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask)); // for signed 32 bit
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << ">>"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }

  int shift_right_arithmetic(int input1, int input2) // ALU control=5 for sra
  {
    // we consider the sign bit in srl
    //  input1=input1&MAX_UNSIGNED;
    int temp = (input1 >> input2) & MAX_UNSIGNED;          // for 32 bit
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask)); // for signed 32 bit
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << ">>"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return 0;
  }
  int subtract(int input1, int input2) // ALU control=7 for sub
  {
    int temp = input1 - input2;
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "-"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return 0;
  }
  int bitwise_xor(int input1, int input2) // ALU control=8 for xor,xori
  {
    int temp = (input1) ^ (input2);
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "^"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return 0;
  }
  int auipc_lui(int input1, int input2) // ALU control=12 for auipc,lui
  {
    // input1=PC, input2=imm
    int var = input2 & (0x000fffff); // generating 20 bit signed integer 
    var = var << 12;
    int temp = input1 + var;
    temp = (-(temp & mask32) + (temp & bit_0_to_31_mask));
    outputBool = true;
    output32 = temp;
    cout << input1 << " "
         << "auipc+lui"
         << " " << input2 << " "
         << "=" << output32 << endl;
    return temp;
  }
  int isEqual(int input1, int input2) // ALU =13 for beq
  {
    if (input1 == input2)
    {
      outputBool = true;
      output32 = 1;
    }
    else
    {
      outputBool = false;
      output32 = 0;
    }
    return 0;
  }
  int NotEqual(int input1, int input2) // ALU =14 for bne
  {
    if (input1 != input2)
    {
      outputBool = true;
      output32 = 1;
    }
    else
    {
      outputBool = false;
      output32 = 0;
    }
    return 0;
  }
  int Greater_than_equal(int input1, int input2) // ALU =15 for bge
  {
    if (input1 >= input2)
    {
      outputBool = true;
      output32 = 1;
      return 1;
    }
    else
    {
      outputBool = false;
      output32 = 0;
      return 0;
    }
  }
  int Less_Than(int input1, int input2) // ALU =16 for blt
  {
    if (input1 < input2)
    {
      outputBool = true;
      output32 = 1;
    }
    else
    {
      outputBool = false;
      output32 = 0;
    }
    return 0;
  }
};
