

// class and function definitions


#include <vector>
#include <bits/stdc++.h>
using namespace std;

class HazardUnit
{
public:
    vector<vector<int>> current_list = {{-1, -1, -1, -1, -1}, {-1, -1, -1, -1, -1}};
    vector<vector<int>> inst_table;

    void add_inst(int opcode, int funct3, int rs1, int rs2, int rd)
    {
        current_list.erase(current_list.begin());
        vector<int> inst_temp = {opcode, funct3, rs1, rs2, rd};
        current_list.push_back(inst_temp);
    }

    void add_null()
    {
        current_list.erase(current_list.begin());
        current_list.push_back({-1, -1, -1, -1, -1});
    }

    vector<int> data_forwarding(int i1, int i2)
    { // knowing the type of forwarding and stalling
        int i2_forwarding = -1;
        int i1_forwarding = -1;

        // first dealing with all cases of i2 and i3 dependence if these do not exist, then only going to i1
        // Case 1 , dependency with i2
        if (i2 == 103)
        {
            i2_forwarding = 33;
            return {i1_forwarding, i2_forwarding};
        }

        // adding more cases for dependencies as required

        if (i2 == 101)
        { // i2 to rs1, then the possible cases of rs2
            i2_forwarding = 31;
            if (i1 == 102)
            { // Case 1 with i1 to rs2
                i1_forwarding = 22;
            }
            else if (i1 == 202)
            { // Case 2 with i1 to rs2
                i1_forwarding = 12;
            }
            return {i1_forwarding, i2_forwarding};
        }
        if (i2 == 102)
        { // i2 to rs2, then the possible cases of rs1
            i2_forwarding = 32;
            if (i1 == 101)
            { // Case 1 with i1 to rs1
                i1_forwarding = 21;
            }
            else if (i1 == 201)
            { // Case 2 with i1 to rs1
                i1_forwarding = 11;
            }
            return {i1_forwarding, i2_forwarding};
        }
        if (i2 == 1)
        {
            i2_forwarding = 31;
            return {i1_forwarding, i2_forwarding};
        }
        // Case 2: Dependency with i2

        // From i2 to both rs1 and rs2
        if (i2 == 203)
        {
            i2_forwarding = 23;
            return {i1_forwarding, i2_forwarding};
        }

        // From i2 to rs1
        if (i2 == 201)
        {
            i2_forwarding = 21;
            // Case 1 with i1 to rs2
            if (i1 == 102)
            {
                i1_forwarding = 22;
            }
            else if (i1 == 202)
            {
                i1_forwarding = 12;
            }
            return {i1_forwarding, i2_forwarding};
        }
        // i2 to rs2
        if (i2 == 202)
        {
            i2_forwarding = 22;
            // Case 1 with i1 to rs1
            if (i1 == 101)
            {
                i1_forwarding = 21;
            }
            // Case 2 with i1 to rs1
            if (i1 == 201)
            {
                i1_forwarding = 11;
            }
            return {i1_forwarding, i2_forwarding};
        }
        // in case only rs1 is present, in I type instructions:-
        // forwarding to i2 rd to rs1 and no forwards from i1
        if (i2 == 2)
        {
            i2_forwarding = 21;
            return {i1_forwarding, i2_forwarding};
        }

        // case 3, dependency with i2:-
        // here only forwarding to rs1 is possible:-
        if (i2 == 3)
        {
            i2_forwarding = 31;
            return {i1_forwarding, i2_forwarding};
        }
        // Case 9, checking dependency with i2:-
        if (i2 == 9)
        {
            i2_forwarding = 505;
            i1_forwarding = -1;
            return {i1_forwarding, i2_forwarding};
        }

        // case 13, checking dependency with i2:-
        if (i2 == 13)
        {
            i2_forwarding = 505;
            i1_forwarding = -1;
            return {i1_forwarding, i2_forwarding};
        }
        // case 17, checking dependency with i2:-
        // if i2 is going to rs1:-
        if (i2 == 1701)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)
            if (i1 == -1 || i1 == 1701 || i1 == 1801)
            {
                i2_forwarding = 31;
            }
            // case 17
            // i1 to rs2 and i1 is R type
            if (i1 == 1702)
            {
                i1_forwarding = 404;
                i2_forwarding = -1;
            }
            // case 18
            // i1 to rs2 and i1 is lw/jalr/jal type:-
            if (i1 == 1802)
            {
                i1_forwarding = 404;
                i2_forwarding = -1;
            }
            return {i1_forwarding, i2_forwarding};
        }

        if (i2 == 1702)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)
            if (i1 == -1 || i1 == 1702 || i1 == 1802)
            {
                i2_forwarding = 0;
            }
            // case 17
            // i1 to rs2 and i1 is R type
            if (i1 == 1701)
            {
                i1_forwarding = -1;
                i2_forwarding = 505;
            }
            // case 18
            // i1 to rs2 and i1 is lw/jalr/jal type:-
            if (i1 == 1801)
            {
                i1_forwarding = -1;
                i2_forwarding = 505;
            }
            return {i1_forwarding, i2_forwarding};
        }

        if (i2 == 1703)
        {
            i1_forwarding = -1;
            i2_forwarding = 310;
            return {i1_forwarding, i2_forwarding};
        }

        // case 18:
        // if i2 is going to rs1:
        if (i2 == 1801)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)
            if (i1 == -1 || i1 == 1701 || i1 == 1801)
            {
                i2_forwarding = 21;
            }
            // case 17
            // i1 to rs2 and i1 is R type
            if (i1 == 1702)
            {
                i1_forwarding = 404;
                i2_forwarding = -1;
            }
            // case 18
            // i1 to rs2 and i1 is lw/jalr/jal type:-
            if (i1 == 1802)
            {
                i1_forwarding = 404;
                i2_forwarding = -1;
            }
            return {i1_forwarding, i2_forwarding};
        }
        if (i2 == 1802)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)
            if (i1 == -1 || i1 == 1702 || i1 == 1802)
            {
                i2_forwarding = 0;
            }
            // case 17
            // i1 to rs2 and i1 is R type
            if (i1 == 1701)
            {
                i1_forwarding = -1;
                i2_forwarding = 505;
            }
            // case 18
            // i1 to rs2 and i1 is lw/jalr/jal type:-
            if (i1 == 1801)
            {
                i1_forwarding = -1;
                i2_forwarding = 505;
            }
            return {i1_forwarding, i2_forwarding};
        }

        if (i2 == 1803)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)

            i1_forwarding = -1;
            i2_forwarding = 505;

            return {i1_forwarding, i2_forwarding};
        }

        if (i2 == 19)
        {
            // only dependent on i2 and not i1 (or i2 is given preference)

            i2_forwarding = 21;

            return {i1_forwarding, i2_forwarding};
        }
        // dealing with cases when there is dependence between i1 and i3 only
        // Case 1
        if (i1 == 103)
        {
            i1_forwarding = 13;
            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 102)
        {
            i1_forwarding = 12;
            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 101 || i1 == 1)
        {
            i1_forwarding = 11;
            return {i1_forwarding, i2_forwarding};
        }
        // Case 2
        if (i1 == 203)
        {
            i1_forwarding = 13;
            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 202)
        {
            i1_forwarding = 12;
            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 201 || i1 == 2)
        {
            i1_forwarding = 11;
            return {i1_forwarding, i2_forwarding};
        }

        // Case 3
        if (i1 == 3)
        {
            i1_forwarding = 11;
            return {i1_forwarding, i2_forwarding};
        }
        // Case 4: None

        // Case 6 : None

        // Case 8: None

        // Case 9
        if (i1 == 9)
        {
            i2_forwarding = -1;
            i1_forwarding = 404;
            return {i1_forwarding, i2_forwarding};
        }

        // Case 13
        if (i1 == 13)
        {
            i1_forwarding = 404;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }

        // Case 17
        if (i1 == 1701)
        {
            i1_forwarding = 11;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 1702)
        {
            i1_forwarding = 404;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }
        if (i1 == 1703)
        {
            i1_forwarding = 404;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }
        // case 18
        if (i1 == 1801)
        {
            i1_forwarding = 11;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }

        if (i1 == 1802)
        {
            i1_forwarding = 404;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }

        if (i1 == 1803)
        {
            i1_forwarding = 404;
            i2_forwarding = -1;

            return {i1_forwarding, i2_forwarding};
        }

        // case 19:
        if (i1 == 19)
        {
            i1_forwarding = 11;
            return {i1_forwarding, i2_forwarding};
        }

        return {-1, -1}; // if no case matches
    }

    int data_stalling(int i1, int i2)
    {
        int stall = -1;
        // dependency with i2
        // Case1
        if (i2 == 103 || i2 == 101 || i2 == 102 || i2 == 1)
        {
            stall = 2;
            return stall;
        }

        // case2
        if (i2 == 203 || i2 == 202 || i2 == 201 || i2 == 2)
        {
            stall = 2;
            return stall;
        }

        // case3
        if (i2 == 3)
        {
            stall = 2;
            return stall;
        }

        // case9
        if (i2 == 9)
        {
            stall = 2;
            return stall;
        }

        // case13
        if (i2 == 13)
        {
            stall = 2;
            return stall;
        }

        // case17
        if (i2 == 1703 || i2 == 1702 || i2 == 1701)
        {
            stall = 2;
            return stall;
        }

        // case18
        if (i2 == 1803 || i2 == 1802 || i2 == 1801)
        {
            stall = 2;
            return stall;
        }

        // case19
        if (i2 == 19)
        {
            stall = 2;
            return stall;
        }

        // dependency with i1:-
        // Case1
        if (i1 == 103 || i1 == 101 || i1 == 102 || i1 == 1)
        {
            stall = 1;
            return stall;
        }

        // case2
        if (i1 == 203 || i1 == 202 || i1 == 201 || i1 == 2)
        {
            stall = 1;
            return stall;
        }

        // case3
        if (i1 == 3)
        {
            stall = 1;
            return stall;
        }

        // case9
        if (i1 == 9)
        {
            stall = 1;
            return stall;
        }

        // case13
        if (i1 == 13)
        {
            stall = 1;
            return stall;
        }

        // case17
        if (i1 == 1703 || i1 == 1702 || i1 == 1701)
        {
            stall = 1;
            return stall;
        }

        // case18
        if (i1 == 1803 || i1 == 1802 || i1 == 1801)
        {
            stall = 1;
            return stall;
        }

        // case19
        if (i1 == 19)
        {
            stall = 1;
            return stall;
        }

        return -1; // if no case matches return stall=-1
    }

    vector<int> check_dependence(int opcode, int funct3, int rs1, int rs2, int rd)
    {
        // add data dependence check via registers
        int dependency_i1 = -1;
        int dependency_i2 = -1;
        vector<int> i2 = current_list[current_list.size() - 1];
        vector<int> i1 = current_list[0];

        // Case2:
        if (i2[0] == 3 || i2[0] == 111 || i2[0] == 103)   //
        {
            if (opcode == 51)
            {
                if (rs1 == i2[4] && rs2 == i2[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i2 = 203;
                }
                else if (rs1 == i2[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i2 = 201;
                }
                else if (rs2 == i2[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i2 = 202;
                    // In case we have a r type instruction just after load.
                }
            }
        }

        if (i2[0] == 3 || i2[0] == 111 || i2[0] == 103)
        {
            if (opcode == 19)
            {
                if (rs1 == i2[4])
                {

                    dependency_i2 = 2;
                }
            }
        }

        if (i1[0] == 3 || i1[0] == 103 || i1[0] == 111)
        {
            if (opcode == 51)
            {
                if (rs1 == i1[4] && rs2 == i1[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i1 = 203;
                }
                else if (rs1 == i1[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i1 = 201;
                }
                else if (rs2 == i1[4])
                {
                    // if rs1 or rs2 == to the register where value is being loaded
                    dependency_i1 = 202;
                    // In case we have a r type instruction just after load.
                }
            }
        }

        if (i1[0] == 3 || i1[0] == 103 || i1[0] == 111)
        {
            if (opcode == 19)
            {
                if (rs1 == i1[4])
                {
                    dependency_i1 = 2;
                }
            }
        }

        // odd Cases
        // Case1
        if (i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55)
        {
            if(opcode == 51)
               { if (rs1 == i2[4] && rs2 == i2[4])
                {
                    dependency_i2 = 103;
                }
                else if (rs1 == i2[4])
                    dependency_i2 = 101;
                else if (rs2 == i2[4])
                    dependency_i2 = 102;}
        }

        if (i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55)
        {
            if (opcode == 51)
            {
                if (rs1 == i1[4] && rs2 == i1[4])
                {
                    dependency_i1 = 103;
                }
                else if (rs1 == i1[4])
                {
                    dependency_i1 = 101;
                }
                else if (rs2 == i1[4])
                {
                    dependency_i1 = 102;
                }
            }
        }

        if (i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55)
        {
            if (opcode == 19)
            {
                if (rs1 == i2[4])
                {
                    dependency_i2 = 1;
                }
            }
        }

        if (i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55)
        {
            if (opcode == 19)
            {
                if (rs1 == i1[4])
                {
                    dependency_i1 = 1;
                }
            }
        }

        if (i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55)
        {
            if (opcode == 3)
            {
                if (rs1 == i2[4])
                {
                    dependency_i2 = 3;
                }
            }
        }

        if (i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55)
        {
            if (opcode == 3)
            {
                if (rs1 == i1[4])
                {
                    dependency_i1 = 3;
                }
            }
        }

        //Case 9
if (i2[0] == 3 || i2[0] == 103 || i2[0] == 111 || i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55) {
    if (opcode == 99) {
        if (rs1 == i2[4] || rs2 == i2[4]) {
            dependency_i2 = 9;
        }
    }
}
if (i1[0] == 3 || i1[0] == 103 || i1[0] == 111 || i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55) {
    if (opcode == 99) {
        if (rs1 == i1[4] || rs2 == i1[4]) {
            dependency_i1 = 9;
        }
    }
}

//Case 13
if (i2[0] == 3 || i2[0] == 103 || i2[0] == 111 || i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55) {
    if (opcode == 103) {
        if (rs1 == i2[4]) {
            dependency_i2 = 13;
        }
    }
}
if (i1[0] == 3 || i1[0] == 103 || i1[0] == 111 || i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55) {
    if (opcode == 103) {
        if (rs1 == i1[4]) {
            dependency_i1 = 13;
        }
    }
}

//Case 17
if (i2[0] == 51 || i2[0] == 19 || i2[0] == 23 || i2[0] == 55) {
    if (opcode == 35) {
        if (rs1 == i2[4] && rs2 == i2[4]) {
            dependency_i2 = 1703;
        } else if (rs1 == i2[4]) {
            dependency_i2 = 1701;
        } else if (rs2 == i2[4]) {
            dependency_i2 = 1702;
        }
    }
}

if (i1[0] == 51 || i1[0] == 19 || i1[0] == 23 || i1[0] == 55) {
    if (opcode == 35) {
        if (rs1 == i1[4] && rs2 == i1[4]) {
            dependency_i1 = 1703;
        } else if (rs1 == i1[4]) {
            dependency_i1 = 1701;
        } else if (rs2 == i1[4]) {
            dependency_i1 = 1702;
        }
    }
}

// Case 18
if (i2[0] == 3 || i2[0] == 103 || i2[0] == 111) {
    if (opcode == 35) {
        if (rs1 == i2[4] && rs2 == i2[4]) {
            dependency_i2 = 1803;
        } else if (rs1 == i2[4]) {
            dependency_i2 = 1801;
        } else if (rs2 == i2[4]) {
            dependency_i2 = 1802;
        }
    }
}

if (i1[0] == 3 || i1[0] == 103 || i1[0] == 111) {
    if (opcode == 35) {
        if (rs1 == i1[4] && rs2 == i1[4]) {
            dependency_i1 = 1803;
        } else if (rs1 == i1[4]) {
            dependency_i1 = 1801;
        } else if (rs2 == i1[4]) {
            dependency_i1 = 1802;
        }
    }
}

// Case 19
if (i2[0] == 3 || i2[0] == 111 || i2[0] == 103) {
    if (opcode == 3) {
        if (rs1 == i2[4]) {
            dependency_i2 = 19;
        }
    }
}

if (i1[0] == 3 || i1[0] == 111 || i1[0] == 103) {
    if (opcode == 3) {
        if (rs1 == i1[4]) {
            dependency_i1 = 19;
        }
    }
}

if (i1[4] == 0) {  // rd of i1 is x0 i.e. no dependency
        dependency_i1 = -1;
    }
if (i2[4] == 0) {  // rd of i2 is x0 i.e. no dependency
        dependency_i2 = -1;
    }

    return {dependency_i1, dependency_i2};

    }

  vector<int> decision_maker(int opcode, int funct3, int rs1, int rs2, int rd, int forwarding_knob) { //to check
        vector<int> dependencies = check_dependence(opcode, funct3, rs1, rs2, rd);

        vector<int> ret_value;
        if (forwarding_knob == 1) {
            ret_value = data_forwarding(dependencies[0], dependencies[1]);
            cout << "Data Hazard code: " << ret_value[0]<<ret_value[1] << endl;
            return ret_value;
        }

        if (forwarding_knob == 0) {
            ret_value.push_back(data_stalling(dependencies[0], dependencies[1]));
            cout << "Data Hazard code: " << ret_value[0] << endl;
            return ret_value;
        }
    }
 void print_table() {
     for(int i=0;i<current_list[0].size();i++)
     {
        cout << current_list[0][i]<<" " ;}
        cout<<", ";
        for(int i=0;i<current_list[1].size();i++)
     {
        cout << current_list[1][i]<<" " ;} 
        cout<<endl;

    }

 void add_table_inst(int opcode, int funct3, int rs1, int rs2, int rd) {
        vector<int> inst_temp = {opcode, funct3, rs1, rs2, rd};
        inst_table.push_back(inst_temp);
    }
   void print_inst_table() {
        for (auto& i : inst_table) {
            for (auto& j : i) {
                cout << j << " ";
            }
            cout << endl;
        }
    }

    int count_data_hazards() {
    int i = 0;
    int count = 0;
    int flag=0;
    int g=inst_table.size();
    cout<<g<<"* "<<endl;
    while (inst_table[i][0] != 0x11 ) {
        int opcode = inst_table[i][0];
        int funct3 = inst_table[i][1];
        int rs1 = inst_table[i][2];
        int rs2 = inst_table[i][3];
        int rd = inst_table[i][4];

        if (i >= 1) { // check between i2, i3
            if ((rs1 != 0 && inst_table[i-1][4] == rs1) || (rs2 != 0 && inst_table[i-1][4] == rs2)) {
                count = count + 1;
            }
        }

        if (i >= 2) {
            if (inst_table[i-1][4] != inst_table[i-2][4]) {
                if ((rs1 != 0 && inst_table[i-2][4] == rs1) || (rs2 != 0 && inst_table[i-2][4] == rs2)) {
                    count = count + 1;
                }
            }
        }

        i = i + 1;
        flag=1;
        //cout<<flag<<" "<<i<<" "<<endl;
    }
   // cout<<flag;
    return count;
}


};

