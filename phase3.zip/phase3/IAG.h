
// InstAddress
#include <bits/stdc++.h>
using namespace std;

class BTB_entry{
    public:
    int inst_address;   //value of instruction
    int target_address; 
    int take;           // this is 1 if the target is to be taken or 0 for not
    
    BTB_entry() {
        take = 0;
        target_address = 0;
        inst_address = 0;
        
    }
};
//Input is control signals and accordingly PC is updated or calculated
class InstructionAddressGenerator
{

public:
    int PC;  // current PC
    int PC_temp; //  to hold the temporary value of PC i.e. PC+4
    int IAGimmediate;  // immediate value for branch instructions
    int PC_buffer;
    unordered_map<int, BTB_entry> BTB; 

    static const int MAX_SIGNED_NUM = 0x7fffffff;
    static const int MIN_SIGNED_NUM = -0x80000000;
    static const int MAX_UNSIGNED_NUM = 0xffffffff;
    static const int MIN_UNSIGNED_NUM = 0x00000000;
    static const int MAX_PC = 0x7ffffffc;

    InstructionAddressGenerator() // constructor
    {
        PC = 0;
        PC_temp = 0;
        IAGimmediate = 0;
        PC_buffer=0;
    }

    int ReadPC()
    {

        return PC;
    }
    void WritePC(int WriteVal, bool writePC) // Writing to PC
    {
        if (writePC == true)
        {
            PC = WriteVal;
        }
    }
     void PCset(int RA, int MuxPCselect)  // Used for Jalr 
    {
        if (MuxPCselect == 0)
        {
            PC_buffer = RA;
        }
    }

    void PCtemp()
    {
        PC_temp = PC + 4;  // storing PC for next instruction first step .This supplied to Result Select before write back
    }

   
  
    void PCUpdate(int MuxINCSelect) //  getting the mux value from control based on the comparison operations performed by the ALU , decides whether to jump or to not
    {
        if (MuxINCSelect == 0) // mux select is 0 
        {
            PC_buffer = PC_buffer+ 4;
        }
        else if (MuxINCSelect == 1) // add offset
        {
            PC_buffer = PC_buffer + IAGimmediate;
            cout << "Instruction Address Generator set " << PC_buffer << " " << IAGimmediate << endl;
            if (PC_buffer > MAX_PC)
            {
                cerr << "Address is not in range of data segment" << endl;  // out of bounds
                exit(1);
            }
        }
    }

      void SetBranchOffset(int boffset) 
    {
        IAGimmediate = boffset; //offset stored
    }

int BTB_check(int inst_pc) {  // to check if instruction in the btb table or not if present return 1 else 0
    if (BTB.find(inst_pc) != BTB.end()) {
        return 1;
    }
    else {
        return 0;
    }
}

void BTB_insert(int inst_pc, int Inst_Target, int take) { // creating table with PC value as index and if take is 1 that means target address is taken
    BTB_entry BTB_temp; 
    BTB_temp.inst_address = inst_pc;
    BTB_temp.target_address = Inst_Target;
    BTB_temp.take = take;
    BTB[inst_pc] = BTB_temp; //making entries
}

};

class InstructionAddressGenerator_non_pipelined
{

public:
    int PC;  // current PC
    int PC_temp; //  to hold the temporary value of PC i.e. PC+4
    int IAGimmediate;  // immediate value for branch instructions
   
    static const int MAX_SIGNED_NUM = 0x7fffffff;
    static const int MIN_SIGNED_NUM = -0x80000000;
    static const int MAX_UNSIGNED_NUM = 0xffffffff;
    static const int MIN_UNSIGNED_NUM = 0x00000000;
    static const int MAX_PC = 0x7ffffffc;

    InstructionAddressGenerator_non_pipelined() // constructor
    {
        PC = 0;
        PC_temp = 0;
        IAGimmediate = 0;
       
    }

    int ReadPC()
    {

        return PC;
    }
    void WritePC(int WriteVal, bool writePC) // Writing to PC
    {
        if (writePC == true)
        {
            PC = WriteVal;
        }
    }
     void PCset(int RA, int MuxPCselect)  // Used for Jalr 
    {
        if (MuxPCselect == 0)
        {
            PC = RA;
        }
    }

    void PCtemp()
    {
        PC_temp = PC + 4;  // storing PC for next instruction first step .This supplied to Result Select before write back
    }

   
  
    void PCUpdate(int MuxINCSelect) //  getting the mux value from control based on the comparison operations performed by the ALU , decides whether to jump or to not
    {
        if (MuxINCSelect == 0) // mux select is 0 
        {
            PC = PC+ 4;
        }
        else if (MuxINCSelect == 1) // add offset
        {
            PC = PC + IAGimmediate;
            cout << "Instruction Address Generator set " << PC << " " << IAGimmediate << endl;
            if (PC > MAX_PC)
            {
                cerr << "Address is not in range of data segment" << endl;  // out of bounds
                exit(1);
            }
        }
    }

      void SetBranchOffset(int boffset) 
    {
        IAGimmediate = boffset; //offset stored
    }




};
