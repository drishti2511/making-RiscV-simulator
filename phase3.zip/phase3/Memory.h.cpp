#include <bits/stdc++.h>
using namespace std;

class ProcessorMemoryInterface {
public:
    const int MAX_SIGNED_NUM = 0x7fffffff;
    const int MIN_SIGNED_NUM = -0x80000000;
    const unsigned int MAX_UNSIGNED_NUM = 0xffffffff;
    const unsigned int MIN_UNSIGNED_NUM = 0x00000000;
    const int MAX_PC = 0x7ffffffc;

    ProcessorMemoryInterface() {
        MAR = 0;
        MAR_pc = 0;
        MDR = 0;
        IRout = 0;
        take_from_rm = false;
        ByteAddressableMemory text_module;
        ByteAddressableMemory data_module;
    }

    void InitMemory(std::map<int, int> PC_INST, std::map<int, int> DATA) {
        for (auto addr : PC_INST) {
            text_module.WriteValueAtAddress(addr.first, 4, PC_INST[addr.first]);
        }
        for (auto addr : DATA) {
            data_module.WriteValueAtAddress(addr.first, 4, DATA[addr.first]);
        }
        cout << "\033[92mProgram and data loaded to memory successfully\033[0m" << std::endl;
    }

    int LoadInstruction(int PC) {
        if (PC % 4 != 0) {
            throw runtime_error("\033[1;31mInstruction not word aligned\033[0m");
        } else if (PC < MIN_UNSIGNED_NUM || PC > MAX_PC) {
            throw runtime_error("\033[1;31mPC out of range!!\033[0m");
        }
        MAR_pc = PC;
        int instruction = 0;
        instruction = text_module.GetUnsignedValueAtAddress(MAR_pc, 4);
        IRout = instruction;
        cout << "\033[93mLoaded instruction from " << std::hex << PC << " " << instruction << "\033[0m" << std::endl;
        return instruction;
    }

    int AccessMemory(bool MEM_read, bool MEM_write, int base_address, int byte_size, int RMin) {
        if (MEM_read == true && MEM_write == false) {
            ReadMemory(base_address, byte_size);
        } else if (MEM_write == true && MEM_read == false) {
            WriteMemory(base_address, byte_size, RMin);
        } else if (MEM_read == false && MEM_write == false) {
            MDR = 0;
        } else if (MEM_read == true && MEM_write == true) {
            throw std::runtime_error("\033[1;31mInvalid control signal received\033[0m");
        }
        return MDR;
    }

    int ReadMemory(int base_address, int no_of_bytes) {
        MAR = base_address;
        MDR = data_module.GetSignedValueAtAddress(MAR, no_of_bytes);
        cout << "\033[93mRead " << no_of_bytes << " bytes from " << std::hex << base_address << ", value= " << MDR << "\033[0m" << std::endl;
        int data = MDR;
        return data;
    }

    void WriteMemory(int base_address, int byte_size, int RMin) {
        MAR = base_address;
        MDR = RMin;
        data_module.WriteValueAtAddress(base_address, byte_size, MDR);
        cout << "\033[93mWrote " << byte_size << " bytes at " << std::hex << base_address << ", value= " << RMin << "\033[0m" << std::endl;
    }
};

class ByteAddressableMemory {
    const int MAX_SIGNED_NUM = 0x7fffffff;
    const int MIN_SIGNED_NUM = -0x80000000;
    const unsigned int MAX_UNSIGNED_NUM = 0xffffffff;
    const unsigned int MIN_UNSIGNED_NUM = 0x00000000;
    const int MAX_PC = 0x7ffffffc;

    unordered_map<int, int> memory;

public:
    int GetUnsignedValueAtAddress(int base_address, int no_of_bytes) {
        int data = 0;
        for (int _byte = 0; _byte < no_of_bytes; ++_byte) {
            if (base_address + _byte < MIN_UNSIGNED_NUM || base_address + _byte > MAX_SIGNED_NUM) {
                throw runtime_error("\033[1;31mAddress is not in range of data segment\033[0m");
            }
            data += memory.find(base_address + _byte) == memory.end() ? 0 : memory[base_address + _byte] * pow(256, _byte);
        }
        return data;
    }

    int GetSignedValueAtAddress(int base_address, int no_of_bytes) {
        if (no_of_bytes == 3) {
            throw runtime_error("\033[1;31mInstruction not supported\033[0m");
        }
        int data = 0;
        for (int _byte = 0; _byte < no_of_bytes; ++_byte) {
            if (base_address + _byte < MIN_UNSIGNED_NUM || base_address + _byte > MAX_SIGNED_NUM) {
                throw runtime_error("\033[1;31mAddress is not in range of data segment\033[0m");
            }
            data += memory.find(base_address + _byte) == memory.end() ? 0 : memory[base_address + _byte] * pow(256, _byte);
        }
        int MSmask = 0;
        int unsigned_num_mask = 0;
        if (no_of_bytes == 1) {
            MSmask = 0x80;
            unsigned_num_mask = 0x7f;
        } else if (no_of_bytes == 2) {
            MSmask = 0x8000;
            unsigned_num_mask = 0x7fff;
        } else if (no_of_bytes == 4) {
            MSmask = 0x80000000;
            unsigned_num_mask = 0x7fffffff;
        }
        data = (- (data & MSmask) + (data & unsigned_num_mask));
        return data;
    }

    void WriteValueAtAddress(int base_address, int no_of_bytes, int write_val) {
        int val = write_val;
        for (int _byte = 0; _byte < no_of_bytes; ++_byte) {
            int byte = val & 0x000000ff;
            if (base_address + _byte > MAX_SIGNED_NUM || base_address + _byte < MIN_UNSIGNED_NUM) {
                throw runtime_error("\033[1;31mMemory address out of range! Segmentation fault(core dumped)\033[0m");
            }
            memory[base_address + _byte] = byte;
            val >>= 8;
        }
    }
};


