#include<bits/stdc++.h>
using namespace std;

#include "Registers.h" // contains 32 GP registers and IR
#include "ProcessorMemoryInterface.h" // processor memory interface
#include "ControlCircuit_piped.h" // generates control signals
#include "IAG.h" // instruction address generator
#include "ALU.h" // arithmetic logic unit
#include "Buffers.h"
#include "Hazard.h"

#define MAX_SIGNED_NUM 0x7fffffff
#define MIN_SIGNED_NUM -0x80000000
#define MAX_UNSIGNED_NUM 0xffffffff
#define MIN_UNSIGNED_NUM 0x00000000

Registers registers; // register object
ProcessorMemoryInterface memory;
ControlModule control_module;
ArithmeticLogicUnit ALUmodule;
InstructionAddressGenerator IAGmodule;
Buffers buffer;
HazardUnit hazard_module;

class ControlBooleans {

public:
    bool decode_stall = false;
    bool fetch_stall = false;
    bool execute_stall = false;
    bool branch_prediction = false;
    bool global_terminate = true;
    int control_hazard_cnt = 0;
    int total_inst = 0;
    int load_store = 0;
    int ALU_ins_cnt = 0;
    int control_inst = 0;
    int bubbles = 0;
    int branch_mis_cnt = 0;
    int data_stall = 0;
    int control_stall = 0;
};

ControlBooleans forward_bool;

// Stage functions
void fetch(int stage, int clock) {
    // to do here
    // if terminate==1, return
    // operation queue will be used in the buffer update stage, not here.
    // fetch the instruction using the value in PC
    // compare it to BTB to check if that is a branch/jump. If it is, update PC to the target.
    // remember to enqueue the PC into the decode_PC_queue
    control_module.controlStateUpdate(0);
    if (control_module.terminate) {
        return;
    }
    // if not control_module.fetch_deque_signal()
    //     return
    // operation queue will be used in the buffer update stage, not here.
    // fetch the instruction using the value in PC
    forward_bool.global_terminate = false;
    buffer.IRbuffer = memory.LoadInstruction(IAGmodule.PC); // update IR buffer
    forward_bool.branch_prediction = IAGmodule.BTB_check(IAGmodule.PC); // update branch prediction
    int target_obj = -1;
    if (forward_bool.branch_prediction) {
        target_obj = IAGmodule.BTB[IAGmodule.PC];
        buffer.Fetch_output_PC_temp = target_obj.target_address;
        cout << "Fetch- Branch prediction. " << buffer.Fetch_output_PC_temp << " predicted" << endl;
    }
    else {
        buffer.Fetch_output_PC_temp = IAGmodule.PC + 4;
    }
}

void decode(int stage, int clock) {
    // if terminate==1, return
    if (control_module.terminate) {
        return;
    }
    if (!control_module.decode_deque_signal()) {
        return;
    }
    // decode stalled
    // check the operation queue. If empty, then operate. Else, don't operate and pop.
    // decode the instruction first in the IR
    forward_bool.global_terminate = false;
    control_module.decode(registers.ReadIR(), IAGmodule.PC);
    if (control_module.terminate) {
        hazard_module.add_table_inst(0x11, 0, 0, 0, 0);
        return;
    }
    // check for hazards(in this case stalls) using the hazard table.
    // requires stall, forwarding kno is turned off, replace 0 with knob signal
    int data_hazard = hazard_module.decision_maker(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd, 0);
    // write stalling code
    if (data_hazard != -1) { // data hazard handled
        std::cout << "##########  DATA HAZARD code " << data_hazard << " ##############\n";
        forward_bool.decode_stall = true;
        forward_bool.fetch_stall = true;
        forward_bool.data_stall += 1;
        control_module.execute_set_NOP();
        control_module.memory_set_NOP();
        control_module.register_set_NOP();
        return;
    }
    // follow steps given in documentation to resolve the hazard by stalling/data forwarding.
    // if all good, push the decoded the signals into the queues.
    int MuxAout = 0;
    int MuxBout = 0;
    if (control_module.MuxBSelect == 0) {
        MuxBout = registers.ReadGpRegisters(control_module.rs2);
    } else if (control_module.MuxBSelect == 1) {
        MuxBout = control_module.imm;
    }
    if (control_module.MuxASelect == 0) {
        MuxAout = registers.ReadGpRegisters(control_module.rs1);
    } else if (control_module.MuxASelect == 1) {
        MuxAout = buffer.Decode_input_PC;
    }
    // code for executing ALU for branch misprediction here.
    // if not control_module.jump:
    buffer.RAtemp = MuxAout;
    buffer.RBtemp = MuxBout;
    buffer.RMtemp = registers.ReadGpRegisters(control_module.rs2);
    control_module.RM_placeholder = buffer.RMtemp;
    control_module.RA_placeholder = buffer.Decode_input_PC + 4; // return address
    // if mtod or to_return:
    //     return;
    ALUmodule.outputBool = 0;
    if (control_module.branch) {
        forward_bool.ALU_ins_cnt += 1;
        ALUmodule.ALUexecute(control_module.ALUOp, control_module.ALUcontrol, buffer.RAtemp, buffer.RBtemp);
    }

    IAGmodule.PC_buffer = buffer.Decode_input_PC;
    control_module.branching_controlUpdate(ALUmodule.outputBool);
    IAGmodule.PCset(buffer.RAtemp, control_module.MuxPCSelect);
    IAGmodule.SetBranchOffset(control_module.imm);
    IAGmodule.PCUpdate(control_module.MuxINCSelect); // value in PC_buffer

    // print(f"\t\t\tiag pc buffer {hex(IAGmodule.PC_buffer)}")

    // buffer.Decode_output_PC_temp = IAGmodule.PC_buffer
    // use branch prediction from the buffer
    // print(f"RAtemp-{buffer.RAtemp} RBtemp-{buffer.RBtemp} RA-{buffer.RA} RB-{buffer.RB}")
    // print(f"\t\t\tRA placeholder- {control_module.RA_placeholder}")
    control_module.branch_misprediction = buffer.Decode_input_branch_prediction ^ (control_module.jump or (control_module.branch and ALUmodule.outputBool));

    if (buffer.Decode_input_branch_prediction == 0 && (control_module.opcode == 111)) {
        std::cout << "BTB entry created. " << IAGmodule.PC_buffer << std::endl;
        IAGmodule.BTB_insert(buffer.Decode_input_PC, IAGmodule.PC_buffer, 1);
    }

    if (buffer.Decode_input_branch_prediction == 0 && control_module.branch) {
        std::cout << "BTB entry created. " << IAGmodule.PC_buffer << std::endl;
        IAGmodule.BTB_insert(buffer.Decode_input_PC, buffer.Decode_input_PC + control_module.imm, 1);
    }

    if (control_module.branch_misprediction) {
        // code here for handling branch misprediction
        std::cout << "Branch Misprediction" << std::endl;

        if (control_module.jump || control_module.branch) {
            forward_bool.control_inst += 1;
        }

        forward_bool.total_inst += 1;
        forward_bool.control_stall += 1;
        forward_bool.branch_mis_cnt += 1;
        forward_bool.bubbles += 1;
        forward_bool.control_hazard_cnt += 1;

        control_module.decode_operation.append(false); // False is the code to indicate a branch misprediction and the decode unit does not have to operate

        hazard_module.add_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd);
        hazard_module.add_table_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd); // end of prog
        buffer.Decode_output_PC_temp = IAGmodule.PC_buffer;
        control_module.execute_set_operate();
        control_module.memory_set_operate();
        control_module.register_set_operate();
        control_module.execute_set_NOP();
        control_module.memory_set_NOP();
        control_module.register_set_NOP();
        return;
    }

    // push NOPs whenever needed, call the execute_set_NOP etc methods is ControlModule according to hazard code
    // if misprediction, perform corrective measures here and return if necessary follow steps given in documentation to resolve the hazard by stalling/data forwarding.
    // in case of jalr, compute effective address and update decode_output_PC_temp by that value.
    // if all good, push the decoded the signals into the queues.
    if (control_module.jump || control_module.branch) {
        forward_bool.control_inst += 1;
    }
    forward_bool.total_inst += 1;
    hazard_module.add_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd);
    hazard_module.add_table_inst(control_module.opcode, control_module.funct3, control_module.rs1, control_module.rs2, control_module.rd); // end of prog
    control_module.execute_set_operate();
    control_module.memory_set_operate();
    control_module.register_set_operate();
}

void execute(int stage, int clock) { // ALU
    // dequeue from the control signals. Check if we need to operate or not
    // False == NOP,
    if (!control_module.execute_deque_signal()) { // this function returns False if memory is in NOP. Also, all control_module.ALUop, etc are updated to 0 in case of NOP, or correct value if OP
        // perform other tasks and return
        return;
    }
    forward_bool.global_terminate = false;
    cout << "Execute Stage" << endl;
    // can use control_module.ALUop etc directly to use as arguments to ALU.
    // cout << "ALUcontrol-" << control_module.ALUcontrol << " ALUop-" << control_module.ALUOp << endl;
    if (control_module.ALUOp) {
        forward_bool.ALU_ins_cnt++;
    }
    ALUmodule.ALUexecute(control_module.ALUOp, control_module.ALUcontrol, buffer.getRA(), buffer.getRB());
    buffer.RZtemp = ALUmodule.output32;    //simple execution
    // cout << "clock- " << clock << " RZtemp-" << buffer.RZtemp << " ALUoutput-" << ALUmodule.output32 << endl;
}

void mem_access(int stage, int clock) {
    // dequeue from the control signals. Check if we need to operate or not
    if (!control_module.memory_deque_signal()) {
        // return code
        return;
    }
    forward_bool.global_terminate = false;
    cout << "Memory Access" << endl;
    //cout << "memory- " << control_module.MemRead << " " << control_module.MemWrite << " " << hex(buffer.getRZ()) << " " << control_module.BytesToAccess << " " << control_module.RM_placeholder << endl;
    if (control_module.MemRead || control_module.MemWrite) {
        forward_bool.load_store++;
    }
    memory.AccessMemory(control_module.MemRead, control_module.MemWrite, buffer.getRZ(), control_module.BytesToAccess, control_module.RM_placeholder);
    //cout << "Memory MDR- " << memory.MDR << " Memory MAR- " << memory.MAR << endl;
    // MuxY
    //cout << "MuxYSelect " << control_module.MuxYSelect << endl;
    if (control_module.MuxYSelect == 0) {
        //cout << "RZ to RY" << endl;
        buffer.RYtemp = buffer.getRZ();
    }
    else if (control_module.MuxYSelect == 1) {
        //cout << "MDR to RY " << memory.MDR << endl;
        buffer.RYtemp = memory.MDR;
    }
    else if (control_module.MuxYSelect == 2) {
        //cout << "\t\tRY set to RA!! " << control_module.RA_placeholder << endl;
        buffer.RYtemp = control_module.RA_placeholder;
    }
    // control_module.controlStateUpdate(stage)
    // memory.AccessMemory(control_module.MemRead,control_module.MemWrite,buffer.getRZtemp(),control_module.BytesToAccess,buffer.getRMtemp())
}

void reg_writeback(int stage, int clock) {
    // dequeue from the control signals. Check if we need to operate or not
    if (!control_module.register_deque_signal()) { // this function returns False if reg_write_back is in NOP. Also, all control_module.ALUop, etc are updated to 0 in case of NOP, or correct value if OP
        // perform other tasks and return
        return;
    }
    forward_bool.global_terminate = false;
    cout << "RegisterWrite stage" << endl;
    registers.WriteGpRegisters(control_module.rd, control_module.RegWrite, buffer.getRY());  // This will simply write back to the registers based on the control signal
}

void buffer_update() {
    if (!forward_bool.fetch_stall) {
        registers.WriteIR(buffer.IRbuffer, 1);
        buffer.Decode_input_branch_prediction = forward_bool.branch_prediction;
        buffer.Decode_input_PC = IAGmodule.PC;
        if (!control_module.branch_misprediction) {
            cout << "PC updated by fetch " << buffer.Fetch_output_PC_temp << endl;
            IAGmodule.PC = buffer.Fetch_output_PC_temp;
        }
    }
    if (!forward_bool.decode_stall) {
        buffer.RA = buffer.RAtemp;
        buffer.RB = buffer.RBtemp;

        if (control_module.branch_misprediction) {
            cout << "PC updated by decode " << IAGmodule.PC_buffer << endl;
            IAGmodule.PC = IAGmodule.PC_buffer;
        }
    }

    buffer.RZ = buffer.RZtemp;
    buffer.RY = buffer.RYtemp;

    if (forward_bool.fetch_stall || forward_bool.decode_stall) {
        forward_bool.bubbles += 1;
        hazard_module.add_null();
    }

    forward_bool.fetch_stall = false;

    //if (!forward_bool.decode_stall) {
    forward_bool.decode_stall = false;
    control_module.branch_misprediction = false;
    //cout << "RZ update, temp-" << buffer.RZtemp << ", RZ-" << buffer.RZ << endl;
    //cout << "buff update- RAtemp-" << buffer.RAtemp << " RBtemp-" << buffer.RBtemp << " RA-" << buffer.RA << " RB-" << buffer.RB << endl;
}

void RunSim(int reg_print=1, int buffprint=1) {
    int clock = 1;
    while (true) {
        // run the stages here, preferably in reverse order.
        // update the buffers in the end
        cout << "\n\033[1;96mCycle " << clock << "\033[0m\n";
        forward_bool.global_terminate = true;
        reg_writeback(4, clock);
        mem_access(3, clock);
        execute(2, clock);
        cout << "Hazard Table:\n";
        hazard_module.print_table();
        decode(1, clock);
        fetch(0, clock);
        buffer_update();
        if (reg_print == 1) {
            cout << "Register file: \n";
            for (int i = 0; i < 32; ++i) {
                cout << "reg[" << i << "]=" << hex << registers.reg[i] << " ";
                if (i % 8 == 0 && i > 0) {
                    cout << "\n";
                }
            }
        }
        cout << "\n";
        if (buffprint == 1) {
            cout << "Pipeline buffers: \n";
            cout << "\033[1;96mPC: " << hex << IAGmodule.PC << " IR: " << std::hex << registers.IR << " RZ: " << buffer.RZ << " RY: " << buffer.RY << "\nRA: " << buffer.RA << " RB: " << buffer.RB << " Decode-Input-PC: " << buffer.Decode_input_PC << "\nBranch predication buffer: " << buffer.Decode_input_branch_prediction << "\033[0m\n";
        }
        cout << "##################################################\n";
        if (forward_bool.global_terminate) {
            cout << "\033[1;92m\nProgram Terminated Successfully\033[0m\n";
            cout << "Stats-\n";
            cout << "Stat1: Cycles: " << clock << "\n";
            cout << "Stat2: Total Instructions: " << forward_bool.total_inst << "\n";
            cout << "Stat3: CPI: " << static_cast<double>(clock) / forward_bool.total_inst << "\n";
            cout << "Stat4: Load/Store: " << forward_bool.load_store << "\n";
            cout << "Stat5: ALU instructions: " << forward_bool.ALU_ins_cnt << "\n";
            cout << "Stat6: Control instructions: " << forward_bool.control_inst << "\n";
            cout << "Stat7: Bubbles: " << forward_bool.bubbles << "\n";
            cout << "Stat8: Total Data Hazards: " << hazard_module.count_data_hazards() << "\n";
            cout << "Stat9: Total Control Hazards: " << forward_bool.control_hazard_cnt << "\n";
            cout << "Stat10: Total branch mispredictions Hazards: " << forward_bool.branch_mis_cnt << "\n";
            cout << "Stat11: Stall due to data hazard: " << forward_bool.data_stall << "\n";
            cout << "Stat12: Stall due to control hazard: " << forward_bool.control_stall << "\n";
            cout << "Cache Stats-" << endl;
            cout << "I$: " << endl;
            cout << "Total Accesses: " << memory.text_module.cache_accesses << endl;
            cout << "Total Hits: " << memory.text_module.cache_hits << endl;
            cout << "Total Miss: " << memory.text_module.cache_miss << endl;
            cout << "D$: " << endl;
            cout << "Total Accesses: " << memory.data_module.cache_accesses << endl;
            cout << "Total Hits: " << memory.data_module.cache_hits << endl;
            cout << "Total Miss: " << memory.data_module.cache_miss << endl;
            return;
        }
        ++clock;
    }
}
