#include <iostream>
#include <bits/stdc++.h>
#include <cmath>
#include <vector>

using namespace std;


class CacheBlock {
public:
    int size;
    vector<int> storage;
    int pref_count;
    bool valid;

    CacheBlock(){

    }
    CacheBlock(int block_size) {
        size = block_size;
        storage.resize(block_size, 0);
        pref_count = -1;
        valid = false;
    }

    vector<int> returnData(int block_offset, int no_of_bytes) {
        vector<int> data;
        for (int byte = 0; byte < no_of_bytes; byte++) {
            if (block_offset >= size) {
                throw "Data not word aligned";
            }
            data.push_back(storage[block_offset]);
            block_offset++;
        }
        return data;
    }

    bool writeData(int block_offset, vector<int> data, int no_of_bytes) {
        valid = true;
        for (int byte = 0; byte < no_of_bytes; byte++) {
            if (block_offset >= size || block_offset < 0) {
                throw "Data not word aligned";
            }
            storage[block_offset] = data[byte];
            block_offset++;
        }
        return true;
    }
};
class CacheSet {

public:
    int _associativity;
    int _block_size;
    vector<CacheBlock> blocks;


    CacheSet(int associativity, int block_size) : _associativity(associativity), _block_size(block_size) {
        blocks = vector<CacheBlock>(_associativity, CacheBlock(_block_size));
    }

    vector<int> getDataFromBlock(int block_index, int block_offset, int no_of_bytes) {
        update_state_hit(block_index);
        return blocks[block_index].returnData(block_offset, no_of_bytes);
    }

    void writeDataToBlock(int block_index, int block_offset, vector<int> data, int no_of_bytes) {
        update_state_hit(block_index);
        blocks[block_index].writeData(block_offset, data, no_of_bytes);
    }

    bool evictBlock(int block_index, vector<int> data) {
        if (data.size() != _block_size) {
            throw runtime_error("Insufficient data received for block eviction");
        }
        blocks[block_index].writeData(0, data, _block_size);
        return true;
    }

    void update_state_hit(int index_up) {
        int temp = blocks[index_up].pref_count;
        for (int i = 0; i < _associativity; i++) {
            if (blocks[i].valid == true) {
                if (blocks[i].pref_count > temp) {
                    blocks[i].pref_count--;
                }
            }
        }
        blocks[index_up].pref_count = _associativity - 1;
    }

    int update_state_miss() {
        int c = 0;
        int index = -1;
        for (int i = 0; i < _associativity; i++) {
            if (blocks[i].valid == false) {
                c = 1;
                break;
            }
        }
        if (c == 1) {
            for (int i = 0; i < _associativity; i++) {
                if (blocks[i].valid == false) {
                    index = i;
                    break;
                }
            }
            for (int i = 0; i < _associativity; i++) {
                if (blocks[i].valid == true) {
                    blocks[i].pref_count--;
                }
            }
            blocks[index].pref_count = _associativity - 1;
            blocks[index].valid = true;
        }
        if (c == 0) {
            for (int i = 0; i < _associativity; i++) {
                if (blocks[i].valid == true) {
                    if (blocks[i].pref_count == 0) {
                        index = i;
                        break;
                    }
                }
            }
            for (int i = 0; i < _associativity; i++) {
                if (blocks[i].valid == true) {
                    blocks[i].pref_count--;
                }
            }
            blocks[index].pref_count = _associativity - 1;
            blocks[index].valid = true;
        }

        return index;
    }
};

class SetAssociativeCache {


public:

    int _associativity;
    int _block_size;
    int _size;
    vector<vector<int>> tag_array; 
    vector<CacheSet> set_array;


    SetAssociativeCache()
    {
    }
    SetAssociativeCache(int associativity, int cache_size, int block_size) {
        _associativity = associativity;
        _block_size = block_size;
        _size = cache_size;
        tag_array = vector<vector<int>>(((_size / _block_size) / _associativity), vector<int>(_associativity, -1)); 
        set_array = vector<CacheSet>((_size / _block_size) / _associativity, CacheSet(_associativity, _block_size)); 
    }
    
    bool checkHit(int tag, int index) 
    { 
        bool isValid = false;
        for (auto block : tag_array[index]) {
            if (block != -1) {
                if (tag == block) {
                    return true;
                }
            }
        }
        return isValid;
    }
    
    vector<int> readDataFromCache(int tag, int index, int block_offset, int no_of_bytes) 
    { 
        bool isHit = false;
        int block_index = 0;
        for (auto block : tag_array[index]) {
            if (block != -1) {
                if (tag == block) {
                    isHit = true;
                    break;
                }
            }
            block_index++;
        }
        if (!isHit) {
            return {-1};
        }
        return set_array[index].getDataFromBlock(block_index, block_offset, no_of_bytes); 
    }
 
    void writeWhenNotHit(int tag, int index, vector<int> data) {
        int block_index = set_array[index].update_state_miss();
        tag_array[index][block_index] = tag;
        set_array[index].evictBlock(block_index, data);
    }

    int writeDataToCache(int tag, int index, int block_offset, vector<int> data, int no_of_bytes) {
        bool isHit = false;
        int block_index = 0;
        for (int i = 0; i < _associativity; i++) {
            if (tag_array[index][i] != -1 && tag == tag_array[index][i]) {
                isHit = true;
                block_index = i;
                break;
            }
        }
        if (!isHit) {
            return -1;
        }
        set_array[index].writeDataToBlock(block_index, block_offset, data, no_of_bytes);
        return 1;
    }
};





class TwoLevelMemory {
public:
    const int MAX_SIGNED_NUM = 0x7fffffff;
    const int MIN_SIGNED_NUM = -0x80000000;
    const int MAX_UNSIGNED_NUM = 0xffffffff;
    const int MIN_UNSIGNED_NUM = 0x00000000;
    const int MAX_PC = 0x7ffffffc;

    unordered_map<int, int> memory;

    int cache_size;
    int cache_block_size;
    int cache_associativity;
    SetAssociativeCache cache_module;
    int total_blocks;
    int total_sets;
    int cache_accesses;
    int cache_hits;
    int cache_miss;

    TwoLevelMemory()
    {

    }

    TwoLevelMemory(int cache_associativity, int cache_size, int cache_block_size) {
        if (cache_size < cache_block_size) {
            throw invalid_argument("Invalid selection of cache block size and cache size");
        }
        if (cache_block_size < 4 || log2(cache_block_size) != floor(log2(cache_block_size))) {
            throw invalid_argument("Cache block size must be a power of 2 and >=4 bytes");
        }
        if (cache_size < 4 || log2(cache_size) != floor(log2(cache_size))) {
            throw invalid_argument("Cache size must be a power of 2 and >=4 bytes");
        }
        if (log2(cache_associativity) != floor(log2(cache_associativity)) ||
            cache_associativity > cache_size / cache_block_size) {
            throw invalid_argument("Associativity must be a power of 2 and less than total number of blocks!");
        }

        cache_size = cache_size;
        cache_block_size = cache_block_size;
        cache_associativity = cache_associativity;
        cache_module = SetAssociativeCache(cache_associativity, cache_size, cache_block_size);
        total_blocks = cache_size / cache_block_size;
        total_sets = total_blocks / cache_associativity;
        cache_accesses = 0;
        cache_hits = 0;
        cache_miss = 0;
    }

    vector<int> generateCacheAddress(int base_address) { 
        int tag = base_address - base_address % cache_block_size; 
        int index = (tag / cache_block_size) % total_sets; 
        int block_offset = base_address % cache_block_size;
        return { tag, index, block_offset };
    }

 int GetUnsignedValueAtAddress( int base_address, int no_of_bytes) {
     int return_data = 0;
    vector<int> cache_address = generateCacheAddress(base_address);
    cache_accesses++;
    bool isHitInCache = cache_module.checkHit(cache_address[0], cache_address[1]);
    vector< int > data; 
    if (isHitInCache) {
        cout << "Cache hit!" << endl;
        cout << "Cache address: [" << cache_address[0] << ", " << cache_address[1] << ", " << cache_address[2] << "]H" << endl;
        cache_hits++;
        data= cache_module.readDataFromCache(cache_address[0], cache_address[1], cache_address[2], no_of_bytes);
        cout << "data is ";
        for ( int i = 0; i < data.size(); i++) {
            cout <<data[i] << " ";
        }
        cout << endl;
    } 
    else {
        
        cout << "Cache miss!" << endl;
        cache_miss++;
        vector<int> block;
        int block_base_address = cache_address[0];
        for ( int byte = 0; byte < cache_block_size; byte++)
        { 
            if (block_base_address + byte < MIN_UNSIGNED_NUM || block_base_address + byte > MAX_SIGNED_NUM) 
            {  
                throw runtime_error("Address is not in range of data segment");
            }
           block.push_back(memory[block_base_address + byte]);;
        }
        cache_module.writeWhenNotHit(cache_address[0], cache_address[1], block);
         int block_offset = cache_address[2];
        for (int byte = 0; byte < no_of_bytes; byte++) {
            if (block_offset+byte >= cache_block_size || block_offset+byte < 0) {
                throw runtime_error("Data not word aligned!");
            }
            data.push_back(block[block_offset+byte]);
        }
    }
    for (int byte = 0; byte < no_of_bytes; byte++) {
        return_data += data[byte]*(256^byte);
    }
    return return_data;
}

void WriteValueAtAddress(int base_address, int no_of_bytes, int write_val, bool init_bool) {
    int val = write_val;
    vector<int> data_to_write;

    if (init_bool) {
        for (int _byte = 0; _byte < no_of_bytes; ++_byte) {
            int byte = val & 0x000000ff;
            if (base_address + _byte > MAX_SIGNED_NUM || base_address + _byte < MIN_UNSIGNED_NUM) {
                throw runtime_error("\033[1;31mMemory address out of range! Segmentation fault(core dumped)\033[0m");
            }
            memory[base_address + _byte] = byte;
            val >>= 8;
        }
        return;
    }

    vector<int> cache_address = generateCacheAddress(base_address);
     cache_accesses++;
    bool isHitInCache = cache_module.checkHit(cache_address[0], cache_address[1]);

    for (int _byte = 0; _byte < no_of_bytes; ++_byte) {
        int byte = val & 0x000000ff;
        data_to_write.push_back(byte);
        if (base_address + _byte > MAX_SIGNED_NUM || base_address + _byte < MIN_UNSIGNED_NUM) {
            throw runtime_error("\033[1;31mMemory address out of range! Segmentation fault(core dumped)\033[0m");
        }
        memory[base_address + _byte] = byte;
        val >>= 8;
    }

    if (isHitInCache) {
        ++cache_hits;
        cache_module.writeDataToCache(cache_address[0], cache_address[1], cache_address[2], data_to_write, no_of_bytes);
    }
    else {
        ++cache_miss;
        vector<int> block;
        int block_base_address = cache_address[0];
        for (int _byte = 0; _byte < cache_block_size; ++_byte) {
            if (block_base_address + _byte < MIN_UNSIGNED_NUM || block_base_address + _byte > MAX_SIGNED_NUM) {
                throw runtime_error("\033[1;31mAddress is not in range of data segment\033[0m");
            }
            block.push_back(memory[block_base_address + _byte]);
        }
        cache_module.writeWhenNotHit(cache_address[0], cache_address[1], block);
    }
}


int GetSignedValueAtAddress(int base_address, int no_of_bytes) {
        if (no_of_bytes == 3) {
            throw runtime_error("\033[1;31mInstruction not supported\033[0m");
        }
        int return_data = 0;
        vector<int> cache_address = generateCacheAddress(base_address);
        cache_accesses++;
        bool isHitInCache = cache_module.checkHit(cache_address[0], cache_address[1]);
        vector<int> data; 
        if (isHitInCache) {
            cout << "Cache hit!\n";
            cache_hits++;
            cout << "Cache address: [" << cache_address[0] << ", " << cache_address[1] << ", " << cache_address[2] << "]H\n";
            data = cache_module.readDataFromCache(cache_address[0], cache_address[1], cache_address[2], no_of_bytes);
            for (int i = 0; i < data.size(); i++) {
                cout << data[i] << " ";
            }
            cout << endl;
        }
        else {
            cout << "Cache miss!\n";
            cache_miss++;
            vector<int> block;
            int block_base_address = cache_address[0] * cache_block_size;
            for (int _byte = 0; _byte < cache_block_size; _byte++) { // fetching the block from memory
                if (block_base_address + _byte < MIN_UNSIGNED_NUM || block_base_address + _byte > MAX_SIGNED_NUM) {  // check if the address lies in range of data segment or not
                    throw runtime_error("\033[1;31mAddress is not in range of data segment\033[0m");
                }
                block.push_back(memory[block_base_address + _byte]);;
            }
            cache_module.writeWhenNotHit(cache_address[0], cache_address[1], block);
            int block_offset = cache_address[2];
            for (int byte = 0; byte < no_of_bytes; byte++) {
                if (block_offset + byte >= cache_block_size || block_offset + byte < 0) {
                    throw runtime_error("Data not word aligned!");
                }
                data.push_back(block[block_offset + byte]);
            }
        }

        for (int _byte = 0; _byte < no_of_bytes; _byte++) {
    return_data += data[_byte] * (256 << (8 * _byte));
}
int MSmask = 0; 
int unsigned_num_mask = 0; 
if (no_of_bytes == 1) {
    MSmask = 0x80;
    unsigned_num_mask = 0x7f;
} else if (no_of_bytes == 2) {
    MSmask = 0x8000;
    unsigned_num_mask = 0x7fff;
} else if (no_of_bytes == 4) {
    MSmask = 0x80000000;
    unsigned_num_mask = 0x7fffffff;
}
return_data = (-(return_data & MSmask) + (return_data & unsigned_num_mask));
return return_data;}};





class ProcessorMemoryInterface { 
public:
    static const int MAX_SIGNED_NUM = 0x7fffffff;
    static const int MIN_SIGNED_NUM = -0x80000000;
    static const  int MAX_UNSIGNED_NUM = 0xffffffff;
    static const int MIN_UNSIGNED_NUM = 0x00000000;
    static const int MAX_PC = 0x7ffffffc;
      int MAR; 
    int MAR_pc;
    int MDR;
    int IRout;
    bool take_from_rm;

    TwoLevelMemory text_module; 
    TwoLevelMemory data_module; 
    ProcessorMemoryInterface()
    {
        MAR = 0;
        MAR_pc = 0;
        MDR = 0;
        IRout = 0;
        take_from_rm = false;
        cout << "Enter specs for Instruction cache: " << endl;
        int cache_size, cache_block_size, cache_associativity;
        cout << "Cache Size in bytes: ";
        cin >> cache_size;
        cout << "Block size in bytes: ";
        cin >> cache_block_size;
        cout << "Associativity: ";
        cin >> cache_associativity;
        TwoLevelMemory text_module(cache_associativity, cache_size, cache_block_size); 
        cout << "Enter specs for Data cache: " << endl;
        cout << "Cache Size in bytes: ";
        cin >> cache_size;
        cout << "Block size in bytes: ";
        cin >> cache_block_size;
        cout << "Associativity: ";
        cin >> cache_associativity;
       TwoLevelMemory data_module(cache_associativity, cache_size, cache_block_size); 
    }

  

    void InitMemory(unordered_map<int, int> PC_INST, unordered_map<int, int> DATA) {
    for (auto addr: PC_INST) 
    { 
        text_module.WriteValueAtAddress(addr.first, 4, addr.second, true);
    }
    for (auto addr: DATA) 
    { 
        data_module.WriteValueAtAddress(addr.first, 4, addr.second, true);
    }
    cout << "\033[92mProgram and data loaded to memory successfully\033[0m" << endl;
}
   int LoadInstruction(int PC) {
    if (PC % 4 != 0) {
        throw runtime_error("\033[1;31mInstruction not word aligned\033[0m");
    }
    if (PC < MIN_UNSIGNED_NUM || PC > MAX_PC) {
        throw runtime_error("\033[1;31mPC out of range!!\033[0m");
    }
    MAR_pc = PC;
     int instruction = 0;
    instruction = text_module.GetUnsignedValueAtAddress(MAR_pc, 4);
    IRout = instruction;
    cout << "\033[93mLoaded instruction from " << hex << PC << " " << instruction << "\033[0m" << endl;
    return instruction;
}

int AccessMemory(bool MEM_read, bool MEM_write, int base_address, int byte_size, int RMin) {
    if (MEM_read && !MEM_write) {
        ReadMemory(base_address, byte_size);
    } else if (MEM_write && !MEM_read) {
        WriteMemory(base_address, byte_size, RMin);
    } else if (!MEM_read && !MEM_write) {
        MDR = 0;
    } else if (MEM_read && MEM_write) 
    { 
        throw runtime_error("\033[1;31mInvalid control signal received\033[0m");
    }
    return MDR;
}


int ReadMemory(int base_address, int no_of_bytes) {
    MAR = base_address;
    MDR = data_module.GetSignedValueAtAddress(MAR, no_of_bytes);
    cout << "\033[93mRead " << no_of_bytes << " bytes from " << hex << base_address << ", value= " << MDR << "\033[0m" << endl;
    int data = MDR;
    return data;
}

void WriteMemory(int base_address, int byte_size, int RMin) {
    MAR = base_address; 
    MDR = RMin; 
    data_module.WriteValueAtAddress(base_address, byte_size, MDR, false);
    cout << "\033[93mWrote " << byte_size << " bytes at " << hex << base_address << ", value=" << RMin << "\033[0m" << endl;
}

};

