
#include <cstdlib>
#include <bits/stdc++.h>
// #include "myParser.h"
// #include "mainf.h"
// #include "main_stall.h"
// #include "main_fwd.h"

using namespace std;

// string toHexa(int value)
// {
//     stringstream stream;
//     stream << "0x" << setfill('0') << std::setw(8) << hex << value;
//     return stream.str();
// }

int main()
{

    //  cout << "RISC-V 32I simulator" << endl;
    // if (argc == 1)
    // {
    //     cout << "File name not supplied!" << endl;
    //     return 1;
    // }

    // parser(argv[1]); // supply input file name

   
    int pipe;
    int data_forward;

    cout << "Knob1: Enter 1 for pipelined execution, 0 for non pipelined execution ";
    cin >> pipe;

    if (pipe != 0 && pipe != 1)
    {
        cout << "Invalid" << endl;
        exit(EXIT_FAILURE);
    }

    if (pipe == 0)
    {
        cout << " Selected: Non Pipelined Execution" << endl;
        // mainf call
      return main_nonpipe();
    }
    else
    {
        cout << "Knob2 for enabling Data Forwarding, 1 for ON, 0 to work with stalling: ";
        cin >> data_forward;

        if (data_forward != 0 && data_forward != 1)
        {
            cout << "Invalid" << endl;
            exit(EXIT_FAILURE);
        }

        if (data_forward == 0)
        {
            cout << " Selected: Pipelined Execution with stalling" << endl;
            // main_stall
            return main_stalling();
        }
        else
        {
            cout << " Selected: Pipelined Execution with Data Forwarding" << endl;
            // main_fwd
            return main_forward();
        }
    }

    return 0;
}