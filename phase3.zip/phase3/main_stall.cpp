#ifndef MAIN_STALL_H
#define MAIN_STALL_H

#include <bits/stdc++.h>
#include <cstdlib>
#include "myParser.h"
#include "RunSim_stall.h"

using namespace std;
string toHexa(int value)
{
    stringstream stream;
    stream << "0x" << setfill('0') << setw(8) << hex << value;
    return stream.str();
}

int main(int argc, char *argv[])
{
    if (argc == 1)
    {
        cout << "File name not supplied!" << endl;
        return 0;
    }

    parser(argv[1]); // supply input file name


   int print_RF, print_BF;
    cout << "Knob3: 1 to Print the register file at the end of each cycle, 0 for not printing "<<endl;
    cin >> print_RF;
    if (print_RF != 0 && print_RF != 1) {
        cout << "Invalid" << endl;
         exit(EXIT_FAILURE);
    }
    cout << "Knob4: 1 to Print the pipeline registers at the end of each cycle, 0 for no printing: "<<endl;
    cin >> print_BF;
    if (print_BF != 0 && print_BF != 1) {
        cout << "Invalid" << endl;
        exit(EXIT_FAILURE);
    }
    // program load
     int nth_inst;
    cout << "Specific instruction: 0 for off, instruction for on: ";
    cin >> nth_inst;
    if (nth_inst < 0) {
    cout << "Invalid " << endl;
     exit(EXIT_FAILURE);}

     
    memory.Initialise(PC_INST, DATA);

    // run the simulator
    RunSim_stall(print_RF,print_BF);

    ofstream Rfile("RegisterDump_stall.mc");

    for (int i = 0; i < 32; i++)
    {                               // for all 32 registers
        Rfile << "x" << i << " "; // print address of register
        if (registers.reg[i] >= 0)
        {
            string str = toHexa(registers.reg[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            replace(str.begin(), str.end(), 'X', 'x');
            Rfile << str;
        }
        else
        {
            uint32_t reg = registers.reg[i] & 0xffffffff; // signed
            string str = toHexa(reg);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            replace(str.begin(), str.end(), 'X', 'x');
            Rfile << str;
        }
        Rfile << "\n";
    }

    Rfile.close();

    ofstream file_mem("MemoryDump_stall.mc");
    unordered_map<int, int> memory1 = memory.memory_data_module.memory;
    vector<int> lst;                                               
    vector<int> t_list;                                          
  file_mem <<"Data:"<<endl; 
    for (auto p : memory1)
    {
        lst.push_back(p.first);
    }
    sort(lst.begin(), lst.end());

    for (auto x : lst)
    {
        int temp = x - (x % 4); // storing base address in temp
        if (find(t_list.begin(), t_list.end(), temp) == t_list.end())
        { // if base address not present in temp_list , then append it
            t_list.push_back(temp);
        }
    }
    sort(t_list.begin(), t_list.end());
    for (auto i : t_list)
    {
        string str = toHexa(i);
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        replace(str.begin(), str.end(), 'X', 'x');
        file_mem << str << " "; // printing base address
        if (memory1.find(i) != memory1.end())
        {
            string str = toHexa(memory1[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " "; // if key in dictionary, print its data
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 1) != memory1.end())
        {
            string str = toHexa(memory1[i + 1]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 2) != memory1.end())
        {
            string str = toHexa(memory1[i + 2]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory1.find(i + 3) != memory1.end())
        {
            string str = toHexa(memory1[i + 3]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00  ";
        }
        file_mem << endl;
    }
file_mem <<"Text:"<<endl; 

     unordered_map<int, int> memory2 = memory.memory_text_module.memory;
    // vector<int> lst;                                               
    // vector<int> t_list;                                          

    for (auto p : memory2)
    {
        lst.push_back(p.first);
    }
    sort(lst.begin(), lst.end());

    for (auto x : lst)
    {
        int temp = x - (x % 4); // storing base address in temp
        if (find(t_list.begin(), t_list.end(), temp) == t_list.end())
        { // if base address not present in temp_list , then append it
            t_list.push_back(temp);
        }
    }
    sort(t_list.begin(), t_list.end());
    for (auto i : t_list)
    {
        string str = toHexa(i);
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        replace(str.begin(), str.end(), 'X', 'x');
        file_mem << str << " "; // printing base address
        if (memory2.find(i) != memory2.end())
        {
            string str = toHexa(memory2[i]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " "; // if key in dictionary, print its data
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 1) != memory2.end())
        {
            string str = toHexa(memory2[i + 1]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 2) != memory2.end())
        {
            string str = toHexa(memory2[i + 2]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00 ";
        }
        if (memory2.find(i + 3) != memory2.end())
        {
            string str = toHexa(memory2[i + 3]);
            transform(str.begin(), str.end(), str.begin(), ::toupper);
            file_mem << str.substr(8) << " ";
        }
        else
        {
            file_mem << "00  ";
        }
        file_mem << endl;
    }
    file_mem.close();
    cout << "\033[1;92m RegisterDump_stall.mc and MemoryDump_stall.mc ready!\033[0m" << std::endl;
    return 0;
}
#endif